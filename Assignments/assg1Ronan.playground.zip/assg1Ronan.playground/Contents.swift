/** PROBLEM 1
 - Design for a function which takes 2 operands (number) and one operator (plus, minus, multiplication and division) and applies the operator on the operands and print and return the result.
 Note: If operand1 is a non-zero number and the operand2 is zero, then the program should not perform the division operand and should print the operation is not possible because one number if zero (this is only for division operator) and return nil.
 - Use both argument label and parameter name for this function.
 - Re-write the same function without using an argument label for the input parameters.
 */

func calculator(math opt: Character, first number1: Int, second number2: Int){
    
    switch opt {
    case "+":
        print("The Sum is \(number1 + number2)!")
    case "-":
        print("The subtraction is \(number1 - number2)!")
    case "*":
        print("The multiplication is \(number1 * number2)!")
    case "/":
        if number2 == 0{
          print ("It is not possible divide by zero in Math!")
        }else{
        print("The division is \(number1 / number2)!")
        }
    default:
        fatalError("There is something wrong!")
    }
}

calculator(math: "/", first: 10, second:01)

/* PROBLEM 2
 Design a function for an application which receive a number and a shape format (which is a string either “SHAPE1” or “SHAPE2” or “SHAPE3”) and prints a shape like this: (if the input is 5)
 
 - Example: input: 5 format: SHAPE1
 *****
 ***
 *
 
 - Example: input: 5 format: SHAPE2
 *****
 ****
 ***
 **
 *
 
 Example: input: 5 format: SHAPE3
 *
 **
 ***
 ****
 *****
 
 - For the function above do not use any argument label (use the _ symbol to call the function)
 - Notice that this function has no return type.
 
 */


func draw( Shape sh: String, number n: Int){
    
    switch sh {
    case "SHAPE1":
        print("I didn't undersdant the first pattern")
        
    case "SHAPE2":
        print("SHAPE2")
        for i in 1...n {
            let s = String(repeating: "*", count: i)
            print(s)
        }
        
    case "SHAPE3":
        print("SHAPE3")
        for i in n...1 {
            let s = String(repeating: "*", count: i)
            print(s)
        }
    default:
            fatalError("problem")
    }
    
}
    draw(Shape :"SHAPE1", number: 10)

/* PROBLEM 3
Design a function which receives a number as input parameter and adds the number together and returns the results. If the number is negative the function will return nil instead.
 */

func receiver(number n: Double){
    if n < 0{
        print("nil")
    }
}

/* PROBLEM 4
 Write a function which receives two number A and B as its parameters:
 First prints all numbers between A and B (A and B not included), which are divisible to both 3 and 5.
 Then prints all numbers between A and B (A included by B not included), which are divisible by either 6 or 7.
 Finally prints all numbers between A and B (A and B both included), which are not divisible by 3.
 Hint: Design a function for each sub problem and then call them inside another function.
 */

func calculator(num1:Int, num2:Int) {
    func checkBetween(_ num1:Int, _ num2:Int) { for value in (num1 + 1)..<num2 {
        if value % 3 == 0 && value % 5 == 0 { print(value)
        } }
    }
    func checkPartial(_ num1:Int, _ num2:Int) { for value in num1..<num2 {
        if value % 6 == 0 || value % 7 == 0 { print(value)
        } }
    }
    func checkAll(_ num1:Int, _ num2:Int) { for value in num1...num2 {
        if value % 3 != 0 { print(value)
        } }
    }
    checkBetween(num1, num2); checkPartial(num1, num2); checkAll(num1, num2)
}
calculator(num1:4, num2:10)

/* PROBLEM 5
 Write a function which receives 2 number A and B as input parameter. Then using A and B, the function considers calculating two mathematical functions:
 • F1(x) = A^x
 • F2(x) = x^B
 The program should find the positive number (and greater than 2), (let’s call is T) which has the following characteristic:
 • For all numbers which are less than T we have F1(x)< F2(x)
 • For all numbers which are greater than or equal T we have F1(x)> F2(x)
 - Hint: Define two functions one for calculating F1(x) and one for calculating F2(x). The  function returns the result based on given A, B and x. Use both argument label and parameter name for the input parameters in the functions in this problem.
 
 */


/* PROBLEM 6
 */
import UIKit
func swap(_ num1:inout Int, _ num2:inout Int) { let temp = num1
    num1 = num2
    num2 = temp }
var num1 = 4
var num2 = 9
swap(&num1,&num2); print(num1, num2)

/* PROBLEM 7
 */
func compareReversedString(_ string:String) -> (Int, String?)? {
    guard !string.isEmpty else { return nil
    }
    var reversedString = "";
    var result:(Int, String?);
    for letter in string.reversed() { reversedString.append(letter)
    }
    if reversedString.contains(string) { result = (1, nil)
    } else {
        result = (0, "Reversed version is not the same")
    }
    return result }
if let (status, message) = compareReversedString("BaBa") { if status == 1 {
    print("The reversed version of this is string is the same as the original") } else if let mess = message {
    print(mess) }
} else {
    print("The string is empty")
}

/* PROBLEM 8
 */
func problem8(inputArray8 inputArray8: [Int], checkNumber checkNumber: Int){
    print("\n---- Problem 8 ----")
    if inputArray8.contains(checkNumber){
        print("\(checkNumber) belongs to the list of integer.")
    } else {
        print("\(checkNumber) does not belong to the list of integer.")
    }
}
problem8(inputArray8: [2, 3, 4, 5, 6, 7, 8,-3, 103], checkNumber: -3)

/* PROBLEM 9
 */

func numberOfOcurrences(list:[Int]) -> (Int, Int)? {
    
    guard !list.isEmpty else {
        return nil
    }
    
    var mapOccurences = [Int: Int]()
    var topOcurrence = 1
    var topNumber = list[0]
    
    for value in list {
        if var currentValue = mapOccurences[value] {
            currentValue = currentValue + 1
            mapOccurences[value] = currentValue
            let currentIndex = list.firstIndex(of: value)!
            let previousIndex = list.firstIndex(of: topNumber)!
            if currentValue >= topOcurrence && currentIndex <= previousIndex {
                topOcurrence = currentValue
                topNumber = value
            }
        } else {
            mapOccurences[value] = 1
        }
    }
    
    return (topNumber, topOcurrence)
}
let result = numberOfOcurrences(list: [2,8,1,6,3,7,2,7,2,1,1])
print(result)

/* PROBLEM 10
 */
func findTopStudent(students:[(String, Int, Int, Int, Int, Int)]) -> (String, Int)? {
    
    guard !students.isEmpty else {
        print("No student informed")
        return nil
    }
    
    var topStudent = ("", 0)
    var gpa = 0;
    for student in students {
        gpa = student.1 + student.2 + student.3 + student.4 + student.5
        gpa = gpa/5
        if gpa > topStudent.1 {
            topStudent = (student.0, gpa)
        }
    }
    
    return topStudent
}
let students = [
    ("Student 1", 34, 98, 75, 17, 0),
    ("Student 2", 73, 35, 27, 84, 58),
    ("Student 3", 83, 73, 23, 95, 73),
    ("Student 4", 49, 84, 35, 95, 34),
]
if let (name, gpa) = findTopStudent(students: students) {
    print("The top student is \(name) and its GPA is \(gpa)")
}

/* PROBLEM 11
 */

/* PROBLEM 12
 */
func problem12(inputArray12 inputArray12: [Int]){
    print("\n---- Problem 12 ----")
    var newArray12 = inputArray12
    for m in 0..<(inputArray12.count - 1){
        if inputArray12[m] == inputArray12[(m+1)]{
            newArray12 = inputArray12.filter{$0 != inputArray12[m]}
        }
    }
    print("The list of distinct numbers : ", terminator: "")
    for answer12 in newArray12{
        print("\(answer12), ", terminator: "")
    }
}
/* PROBLEM 13
 */

/* PROBLEM 14
 */

/* PROBLEM 15
 */
func problem15(_ opt: Character) -> ((Int, Int) -> Double)?{
    func sum(_ num1: Int, _ num2: Int) -> Double {
        return Double(num1 + num2)
    }
    
    func sub(_ num1: Int, _ num2: Int) -> Double {
        return Double(num1 - num2)
    }
    
    func multiplu(_ num1: Int, _ num2: Int) -> Double {
        return Double(num1 * num2)
    }
    
    func devision(_ num1: Int, _ num2: Int) -> Double {
        return Double(Double(num1) / Double(num2))
    }
    
    func remainder(_ num1: Int, _ num2: Int) -> Double {
        return Double(num1 % num2)
    }
    
    switch opt {
    case "+":
        return sum
    case "-":
        return sub
    case "*":
        return multiplu
    case "/":
        return devision
    case "%":
        return remainder
    default:
        return nil
    }
}

print("\n\n---- Problem 15 ----")
let num1 = 23
let num2 = 5

if let f = problem15("+"){
    print("\(num1) + \(num2) = \(f(num1, num2))")
}

if let f = problem15("-"){
    print("\(num1) - \(num2) = \(f(num1, num2))")
}

if let f = problem15("*"){
    print("\(num1) * \(num2) = \(f(num1, num2))")
}

if let f = problem15("/"){
    print("\(num1) / \(num2) = \(f(num1, num2))")
}

if let f = problem15("%"){
    print("\(num1) % \(num2) = \(f(num1, num2))")
}


